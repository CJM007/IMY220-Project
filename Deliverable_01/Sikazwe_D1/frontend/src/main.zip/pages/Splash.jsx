function Splash() {
  return (
    <div>
      <h1>Dog-Eared</h1>
      <p>Splash page. Login/Signup form go here.</p>
    </div>
  );
}

export default Splash;
